package com.mascotasmunicipales

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import android.text.InputFilter
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import android.util.LruCache
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.activity.OnBackPressedCallback
import androidx.core.widget.doAfterTextChanged
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.firebase.firestore.ListenerRegistration
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.CopyrightOverlay
import org.osmdroid.views.overlay.Marker
import java.io.File
import java.text.DateFormat
import java.text.Normalizer
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {
    companion object {
        private val ZIPAQUIRA_CENTER = GeoPoint(5.021476, -73.990955)
        private val SEARCH_MARKS = "\\p{M}+".toRegex()
        private val PUBLIC_QR_CODE = "ZPQ-[A-Z0-9]{1,32}".toRegex()
    }

    private lateinit var model: AppViewModel
    private val repo get() = model.repo
    private val teal get() = when {
        highContrast -> Color.BLACK
        colorblindPalette -> Color.rgb(0, 82, 155)
        else -> Color.rgb(20, 127, 149)
    }
    private val bg get() = if (highContrast) Color.WHITE else Color.rgb(241, 246, 248)
    private val dark get() = if (highContrast) Color.BLACK else Color.rgb(32, 49, 58)
    private val gray get() = if (highContrast) Color.BLACK else Color.rgb(85, 100, 109)
    private val border get() = if (highContrast) Color.BLACK else Color.rgb(214, 227, 232)
    private val softTeal get() = when {
        highContrast -> Color.WHITE
        colorblindPalette -> Color.rgb(229, 239, 249)
        else -> Color.rgb(226, 241, 244)
    }
    private val tealDark get() = when {
        highContrast -> Color.BLACK
        colorblindPalette -> Color.rgb(0, 69, 120)
        else -> Color.rgb(14, 97, 114)
    }
    private val textScale get() = if (largeText) 1.3f else 1f
    private val accessibilityPreferences by lazy { getSharedPreferences("accessibility", MODE_PRIVATE) }
    private var largeText = false
    private var highContrast = false
    private var colorblindPalette = false
    private var accessibilityOpen = false
    private var publicQrOpen = false
    private var accessibilityScrollY = 0
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    private val listeners = mutableListOf<ListenerRegistration>()
    private var screenGeneration = 0
    private var tab: Int
        get() = model.tab
        set(value) { model.tab = value }
    private var syncMessage = ""
    private var updateDraftUi: (() -> Unit)? = null
    private var updateAuthUi: ((SessionState) -> Unit)? = null
    private val work = WorkRepository()
    private var activeMap: MapView? = null
    private val photoCache = object : LruCache<String, Bitmap>(4096) {
        override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        largeText = accessibilityPreferences.getBoolean("large_text", false)
        highContrast = accessibilityPreferences.getBoolean("high_contrast", false)
        colorblindPalette = accessibilityPreferences.getBoolean("colorblind_palette", false)
        configureOpenStreetMap()
        accessibilityOpen = savedInstanceState?.getBoolean("accessibilityOpen") ?: false
        accessibilityScrollY = savedInstanceState?.getInt("accessibilityScrollY") ?: 0
        model = ViewModelProvider(this)[AppViewModel::class.java]
        model.session.observe(this) { session ->
            val authUi = updateAuthUi
            if (session.phase in listOf("signedOut", "authenticating") && authUi != null) authUi(session)
            else showApp()
        }
        model.draftsChanged.observe(this) { updateDraftUi?.invoke() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (accessibilityOpen) {
                    accessibilityOpen = false
                    if (model.ready) profileMenu() else authScreen()
                    return
                }
                if (publicQrOpen) {
                    publicQrOpen = false
                    authScreen()
                    return
                }
                if (!model.ready || model.screen == "home") finish()
                else renderRoute(when {
                    model.screen == "profile" -> model.previousScreen
                    model.screen == "about" -> "profile"
                    model.screen == "qr" -> "pets"
                    model.screen == "newPet" || model.screen.startsWith("pet:") -> "pets"
                    model.screen == "newReport" || model.screen.startsWith("report:") -> "reports"
                    else -> "home"
                })
            }
        })
    }
    override fun onResume() { super.onResume(); activeMap?.onResume() }
    override fun onPause() { activeMap?.onPause(); model.flush(); super.onPause() }
    override fun onSaveInstanceState(outState: Bundle) {
        model.flush()
        outState.putBoolean("accessibilityOpen", accessibilityOpen)
        outState.putInt("accessibilityScrollY", (content.getChildAt(0) as? ScrollView)?.scrollY ?: 0)
        super.onSaveInstanceState(outState)
    }
    override fun onDestroy() { clearListeners(); releaseMap(); super.onDestroy() }
    private fun remember(route: String, selectedTab: Int = tab) {
        accessibilityOpen = route == "accessibility"
        tab = selectedTab; model.navigate(route)
        updateNavigation()
    }
    private fun updateNavigation() {
        if (!::nav.isInitialized) return
        (0 until nav.childCount).forEach {
            (nav.getChildAt(it) as LinearLayout).apply {
                val selected = model.ready && it == tab && !accessibilityOpen
                background = if (selected) GradientDrawable().apply {
                    setColor(if (highContrast) Color.BLACK else softTeal)
                    cornerRadius = dp(14).toFloat()
                } else null
                val icon = getChildAt(0) as ImageView
                val label = getChildAt(1) as TextView
                val color = if (selected && highContrast) Color.WHITE else if (selected) teal else gray
                icon.imageTintList = ColorStateList.valueOf(color)
                label.setTextColor(color); label.typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                contentDescription = if (selected) "${label.text}, pestaña seleccionada" else "${label.text}, abrir pestaña"
            }
        }
    }
    private fun renderRoute(route: String) {
        if (!model.ready) return
        when {
            route == "work" -> workHome()
            route == "workevent" -> eventProposal()
            route.startsWith("workcase:") -> workCase(route.removePrefix("workcase:"))
            route == "accessibility" -> accessibilityScreen()
            route == "about" -> aboutScreen()
            route == "qr" -> qrLookupScreen()
            route == "newPet" -> newPet()
            route == "newReport" -> newReport()
            route.startsWith("pet:") -> petDetail(route.removePrefix("pet:"))
            route.startsWith("report:") -> reportDetail(route.removePrefix("report:"))
            route == "pets" -> pets()
            route == "reports" -> reports()
            route == "territory" -> territory()
            route == "profile" -> profileMenu()
            else -> home()
        }
    }
    private fun clearListeners() { listeners.forEach { it.remove() }; listeners.clear() }
    private fun searchable(value: String): String = Normalizer.normalize(value.lowercase(Locale.forLanguageTag("es-CO")), Normalizer.Form.NFD)
        .replace(SEARCH_MARKS, "").trim()
    private fun publicQrCode(value: String): String? = PUBLIC_QR_CODE.find(value.trim().uppercase(Locale.ROOT))?.value
    private fun configureOpenStreetMap() {
        val osm = Configuration.getInstance()
        val base = File(cacheDir, "openstreetmap")
        val tiles = File(base, "tiles")
        tiles.mkdirs()
        osm.userAgentValue = "MascotasMunicipales ($packageName)"
        osm.osmdroidBasePath = base
        osm.osmdroidTileCache = tiles
        osm.tileFileSystemCacheMaxBytes = 24L * 1024L * 1024L
        osm.tileFileSystemCacheTrimBytes = 20L * 1024L * 1024L
    }
    @Suppress("ClickableViewAccessibility")
    private fun attachTerritoryMap(holder: FrameLayout) {
        val map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            setTilesScaledToDpi(true)
            minZoomLevel = 11.0
            maxZoomLevel = 18.0
            setScrollableAreaLimitDouble(BoundingBox(5.18, -73.82, 4.86, -74.18))
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.SHOW_AND_FADEOUT)
            controller.setZoom(14.0)
            controller.setCenter(ZIPAQUIRA_CENTER)
            contentDescription = "Mapa interactivo de Zipaquirá. Usa gestos para desplazar y ampliar."
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
            overlays.add(Marker(this).apply {
                position = ZIPAQUIRA_CENTER
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                title = "Zipaquirá"
                snippet = "Centro de referencia municipal"
            })
            overlays.add(CopyrightOverlay(this@MainActivity).apply {
                setCopyrightNotice("© OpenStreetMap contributors")
            })
            setOnTouchListener { view, event ->
                view.parent?.requestDisallowInterceptTouchEvent(
                    event.actionMasked != MotionEvent.ACTION_UP && event.actionMasked != MotionEvent.ACTION_CANCEL
                )
                if (event.actionMasked == MotionEvent.ACTION_UP) view.performClick()
                false
            }
        }
        activeMap = map
        holder.addView(map, FrameLayout.LayoutParams(-1, -1))
        map.onResume()
    }
    private fun releaseMap() {
        activeMap?.let { map ->
            map.onPause()
            map.onDetach()
        }
        activeMap = null
    }
    private fun setPhoto(view: ImageView, resource: Int, thumbnailSidePx: Int = 0) {
        // El detalle conserva el muestreo anterior; las tarjetas no necesitan un bitmap de 512 px.
        var sample = 2
        if (thumbnailSidePx > 0) {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeResource(resources, resource, bounds)
            while (bounds.outWidth / (sample * 2) >= thumbnailSidePx &&
                bounds.outHeight / (sample * 2) >= thumbnailSidePx) sample *= 2
        }
        // Una miniatura nunca debe sustituir la imagen de mayor resolución del detalle.
        val key = "$resource:$sample"
        val bitmap = photoCache[key] ?: BitmapFactory.decodeResource(resources, resource,
            BitmapFactory.Options().apply { inSampleSize = sample })?.also { photoCache.put(key, it) }
        if (bitmap != null) view.setImageBitmap(bitmap) else view.setImageResource(resource)
    }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun tv(value: String, size: Float = 14f, bold: Boolean = false, color: Int = dark) = TextView(this).apply {
        text = value; textSize = size * textScale; setTextColor(color)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        setPadding(dp(2), dp(3), dp(2), dp(3))
        includeFontPadding = true
    }
    private fun heading(value: String, size: Float = 16f, color: Int = dark) = tv(value, size, true, color).apply {
        ViewCompat.setAccessibilityHeading(this, true)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(18), dp(16), dp(6)) }
    }
    private fun rounded(fill: Int, radius: Int = 16, stroke: Int = border, strokeWidth: Int = 1) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(radius).toFloat()
        if (strokeWidth > 0) setStroke(dp(if (highContrast) 2 else strokeWidth), stroke)
    }
    private fun shape() = rounded(Color.WHITE)
    private fun root() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(0, 0, 0, dp(16))
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = shape(); setPadding(dp(16), dp(14), dp(16), dp(14))
        elevation = if (highContrast) 0f else dp(2).toFloat()
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(6), dp(12), dp(6)) }
    }
    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 13f * textScale; setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD; setOnClickListener { action() }
        isAllCaps = false; minHeight = dp(52); stateListAnimator = null
        val colors = ColorStateList(
            arrayOf(intArrayOf(-android.R.attr.state_enabled), intArrayOf()),
            intArrayOf(if (highContrast) Color.LTGRAY else Color.rgb(139, 184, 193), teal)
        )
        background = RippleDrawable(ColorStateList.valueOf(Color.argb(55, 255, 255, 255)),
            GradientDrawable().apply { setColor(colors); cornerRadius = dp(14).toFloat() }, rounded(Color.WHITE, 14, Color.TRANSPARENT, 0))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(7), dp(12), dp(7)) }
    }
    private fun secondaryButton(label: String, action: () -> Unit) = button(label, action).apply {
        setTextColor(teal)
        background = RippleDrawable(ColorStateList.valueOf(Color.argb(35, 20, 127, 149)),
            rounded(if (highContrast) Color.WHITE else softTeal, 14, teal), rounded(Color.WHITE, 14, Color.TRANSPARENT, 0))
    }
    private fun field(hintValue: String, maxLength: Int = 2000) = EditText(this).apply {
        hint = hintValue; background = rounded(Color.WHITE, 13); setPadding(dp(14), dp(11), dp(14), dp(11))
        textSize = 16f * textScale; minHeight = dp(52); setTextColor(dark); setHintTextColor(gray)
        filters = arrayOf(InputFilter.LengthFilter(maxLength))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(5), dp(12), dp(5)) }
    }
    private fun select(values: List<String>) = Spinner(this).apply {
        id = View.generateViewId()
        adapter = object : ArrayAdapter<String>(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, values) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View =
                super.getView(position, convertView, parent).apply {
                    (this as? TextView)?.textSize = 16f * textScale
                    minimumHeight = dp(48)
                }
            override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View =
                super.getDropDownView(position, convertView, parent).apply {
                    (this as? TextView)?.textSize = 16f * textScale
                    minimumHeight = dp(48)
                }
        }
        minimumHeight = dp(52); background = rounded(Color.WHITE, 13)
        setPadding(dp(8), 0, dp(8), 0)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(4), dp(12), dp(7)) }
    }
    private fun spinnerLabel(label: String, spinner: Spinner) = tv(label, 13f, true, gray).apply {
        labelFor = spinner.id
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(8), dp(14), 0) }
    }
    private fun scroll(v: View) = ScrollView(this).apply {
        addView(v); isFillViewport = true; clipToPadding = false; overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
    }
    private fun header(title: String, subtitle: String = "") = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(tealDark, teal)).apply {
            cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, dp(22).toFloat(), dp(22).toFloat(), dp(22).toFloat(), dp(22).toFloat())
        }
        elevation = if (highContrast) 0f else dp(3).toFloat()
        setPadding(dp(20), dp(20), dp(16), dp(20))
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            addView(heading(title, 22f, Color.WHITE).apply { layoutParams = LinearLayout.LayoutParams(-1, -2) })
            if (subtitle.isNotBlank()) addView(tv(subtitle, 12f, false, Color.WHITE).apply { alpha = .88f })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        if (model.ready) {
            val inProfile = model.screen in listOf("profile", "accessibility", "about")
            val inAbout = model.screen == "about"
            addView(tv(if (inProfile) "Volver" else "Perfil", 12f, true, teal).apply {
                gravity = Gravity.CENTER
                minHeight = dp(56); minWidth = dp(64)
                contentDescription = if (accessibilityOpen || inAbout) "Volver al menú de perfil" else if (inProfile) "Volver a la pantalla anterior" else "Abrir menú de perfil"
                background = RippleDrawable(ColorStateList.valueOf(Color.argb(35, 20, 127, 149)), shape(), rounded(Color.WHITE, 14, Color.TRANSPARENT, 0))
                setOnClickListener {
                    if (accessibilityOpen) profileMenu()
                    else if (inAbout) profileMenu()
                    else if (inProfile) renderRoute(model.previousScreen)
                    else { model.previousScreen = model.screen; profileMenu() }
                }
            }, LinearLayout.LayoutParams(-2, -2))
        }
    }
    private fun show(v: View) {
        screenGeneration++; clearListeners(); updateDraftUi = null; updateAuthUi = null
        releaseMap()
        content.removeAllViews(); content.addView(v)
        v.alpha = 0f; v.translationY = dp(8).toFloat()
        v.animate().alpha(1f).translationY(0f).setDuration(180L).start()
    }

    private fun pill(value: String, positive: Boolean = true) = tv(value, 11f, true, if (highContrast) Color.BLACK else tealDark).apply {
        gravity = Gravity.CENTER_VERTICAL
        val fill = if (highContrast) Color.WHITE else if (positive) softTeal else Color.rgb(235, 240, 242)
        background = rounded(fill, 30,
            if (highContrast) Color.BLACK else Color.TRANSPARENT, if (highContrast) 1 else 0)
        setPadding(dp(10), dp(5), dp(10), dp(5))
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, dp(7), 0, 0) }
    }

    private fun infoCard(title: String, detail: String, symbol: String = "i") = card().apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        addView(tv(symbol, 18f, true, teal).apply {
            gravity = Gravity.CENTER; background = rounded(softTeal, 24, Color.TRANSPARENT, 0)
            minWidth = dp(42); minHeight = dp(42)
        })
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0)
            addView(tv(title, 14f, true)); addView(tv(detail, 12f, false, gray))
        }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun metricCard(value: TextView, label: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = shape(); setPadding(dp(16), dp(14), dp(16), dp(14))
        elevation = if (highContrast) 0f else dp(2).toFloat()
        addView(value); addView(tv(label, 12f, false, gray))
    }

    private fun messageView(value: String) = tv(value, 12f, false, gray).apply {
        accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        background = rounded(if (highContrast) Color.WHITE else softTeal, 12, if (highContrast) Color.BLACK else Color.TRANSPARENT,
            if (highContrast) 1 else 0)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(7), dp(12), dp(7)) }
    }
    @Suppress("DEPRECATION")
    private fun applySystemBars() {
        window.statusBarColor = teal
        // Antes de API 26 Android solo dibuja iconos claros en esta barra.
        val darkNavigationIcons = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
        window.navigationBarColor = if (darkNavigationIcons) bg else tealDark
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = darkNavigationIcons
        }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun date(t: com.google.firebase.Timestamp?) = t?.toDate()?.let {
        DateFormat.getDateInstance(DateFormat.MEDIUM, Locale.forLanguageTag("es-CO")).format(it)
    } ?: "Pendiente"
    private fun dateTime(t: com.google.firebase.Timestamp?) = t?.toDate()?.let {
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, Locale.forLanguageTag("es-CO")).format(it)
    } ?: "Fecha pendiente"
    private fun state(pending: Boolean, cache: Boolean) = when {
        pending -> "Pendiente de sincronización"
        cache -> "Dato en caché · sin confirmación reciente"
        else -> "Sincronizado"
    }
    private fun showApp() {
        clearListeners()
        applySystemBars()
        val r = root(); content = FrameLayout(this)
        r.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        nav = LinearLayout(this).apply {
            setBackgroundColor(Color.WHITE); setPadding(dp(5), dp(6), dp(5), dp(6))
            elevation = dp(8).toFloat()
            visibility = if (model.ready) View.VISIBLE else View.GONE
        }
        val navItems = listOf(
            Triple("Inicio", R.drawable.ic_nav_home, 0),
            Triple("Reportes", R.drawable.ic_nav_report, 1),
            Triple("Mascotas", R.drawable.ic_nav_pets, 2),
            Triple("Territorio", R.drawable.ic_nav_map, 3)
        )
        navItems.forEach { (label, icon, i) ->
            nav.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; minimumHeight = dp(62)
                setPadding(dp(2), dp(7), dp(2), dp(5)); isClickable = true; isFocusable = true
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(icon); importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                }, LinearLayout.LayoutParams(dp(23), dp(23)))
                addView(tv(label, 10f, i == tab, if (i == tab) teal else gray).apply {
                    gravity = Gravity.CENTER; importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                })
                contentDescription = if (i == tab) "$label, pestaña seleccionada" else "$label, abrir pestaña"
                setOnClickListener { accessibilityOpen = false; tab = i; renderTab() }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        r.addView(nav); setContentView(r); updateNavigation()
        when (model.session.value?.phase) {
            "ready" -> renderRoute(model.screen)
            "signedOut", "authenticating" -> if (accessibilityOpen) accessibilityScreen() else authScreen()
            else -> sessionScreen()
        }
    }
    private fun renderTab() {
        if (!model.ready) return
        when (tab) { 0 -> home(); 1 -> reports(); 2 -> pets(); 3 -> territory(); else -> profileMenu() }
    }
    private fun sessionScreen() {
        val session = model.session.value ?: SessionState("starting")
        val c = root(); c.addView(header("Tu cuenta", "Mascotas Municipales"))
        c.addView(infoCard("Preparando tu espacio", session.message.ifBlank { "Preparando sesión…" }, "⋯"))
        if (session.phase == "profileError") c.addView(button("REINTENTAR PERFIL") { model.prepareProfile() })
        if (repo.uid != null) c.addView(secondaryButton("CERRAR SESIÓN") { model.logout() })
        show(scroll(c))
    }
    private fun authScreen() {
        publicQrOpen = false
        val c = root(); c.addView(header("🐾 Mascotas Municipales", "Registro e ingreso · Zipaquirá"))
        c.addView(heading("Bienvenido"))
        c.addView(tv("Ingresa para registrar mascotas, crear reportes y consultar su seguimiento.", 14f, false, gray).apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), 0, dp(16), dp(10)) }
        })
        val form = card()
        form.addView(tv("Datos de acceso", 16f, true))
        val email = field("Correo electrónico").apply { inputType = 33 }; form.addView(email)
        val password = field("Contraseña (mínimo 6 caracteres)").apply {
            inputType = 129; isSaveEnabled = false
        }; form.addView(password)
        val message = messageView(""); form.addView(message)
        val workspace = select(listOf("Ciudadano", "Veterinario", "Administrador de la dependencia"))
        form.addView(spinnerLabel("Ingresar como", workspace)); form.addView(workspace)
        form.addView(tv("Elegir una opción no concede permisos. Las cuentas profesionales requieren aprobación.", 12f, false, gray).apply {
            setPadding(dp(14), dp(5), dp(14), dp(8))
        })
        val login = button("INGRESAR") {
            model.requestedWorkspace = listOf("citizen", "vet", "admin")[workspace.selectedItemPosition]
            model.authenticate(email.text.toString(), password.text.toString(), false)
        }
        val register = button("CREAR CUENTA CIUDADANA") {
            model.requestedWorkspace = "citizen"
            model.authenticate(email.text.toString(), password.text.toString(), true)
        }
        form.addView(login); form.addView(register); c.addView(form)
        val accessibility = secondaryButton("AJUSTES DE ACCESIBILIDAD") { accessibilityOpen = true; accessibilityScreen() }
        c.addView(accessibility)
        c.addView(secondaryButton("CONSULTAR MASCOTA POR QR") { qrLookupScreen() })
        message.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        show(scroll(c))
        updateAuthUi = { session ->
            val busy = session.phase == "authenticating"
            login.isEnabled = !busy; register.isEnabled = !busy; accessibility.isEnabled = !busy
            email.isEnabled = !busy; password.isEnabled = !busy
            workspace.isEnabled = !busy
            message.text = session.message.ifBlank { "Ingresa con tu correo y contraseña." }
        }
        updateAuthUi?.invoke(model.session.value ?: SessionState("signedOut"))
    }
    private fun bind(field: EditText, draft: Draft, key: String) {
        field.setText(draft.value(key)); field.isEnabled = !draft.locked
        field.doAfterTextChanged { if (draft.set(key, it.toString())) model.draftEdited() }
    }
    private fun bind(spinner: Spinner, draft: Draft, key: String, values: List<String>) {
        spinner.setSelection(values.indexOf(draft.value(key, values.first())).coerceAtLeast(0))
        spinner.isEnabled = !draft.locked
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (draft.set(key, values[position])) model.draftEdited()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
    }
    private fun attachSubmission(kind: String, message: TextView, submit: Button, another: Button, inputs: List<View>) {
        message.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        updateDraftUi = {
            val d = model.draft(kind)
            message.text = if (model.storageError.isNotBlank()) model.storageError else when (d.status) {
                "pending" -> "Pendiente de sincronización. Conservamos este envío al cerrar la app."
                "confirmed" -> "Sincronizado · confirmado por el servidor."
                "failed" -> "Sin confirmar: ${d.error}"
                else -> "Borrador guardado en este dispositivo."
            }
            inputs.forEach { it.isEnabled = !d.locked }
            submit.isEnabled = d.status !in listOf("pending", "confirmed") && model.storageError.isEmpty()
            if (d.status == "failed") submit.text = "REINTENTAR MISMO ENVÍO"
            another.visibility = if (d.status == "confirmed") View.VISIBLE else View.GONE
        }
        updateDraftUi?.invoke()
    }
    private fun home() {
        remember("home", 0)
        val c = root(); c.addView(header("🐾 Mascotas Municipales", "Prototipo académico · Zipaquirá"))
        c.addView(infoCard("Tus datos, incluso sin conexión", "Los cambios ciudadanos se conservan en este dispositivo y se confirman cuando responde Firebase.", "✓"))
        c.addView(heading("Resumen"))
        val petsNumber = tv("Cargando…", 22f, true, teal)
        val reportsNumber = tv("Cargando…", 22f, true, teal)
        c.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), 0, dp(8), 0)
            addView(metricCard(petsNumber, "Mascotas registradas\nhasta 1000"), LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
            addView(metricCard(reportsNumber, "Mis reportes\nabiertos"), LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        })
        repo.petCount { count, _ -> petsNumber.text = count?.toString() ?: "Sin conexión" }
        repo.activeReportCount { count, _ -> reportsNumber.text = count?.toString() ?: "Sin conexión" }
        c.addView(heading("Acciones rápidas"))
        c.addView(button("VER MASCOTAS") { tab = 2; renderTab() })
        c.addView(button("NUEVO REPORTE") { newReport() })
        c.addView(button("CONSULTAR QR") { qrLookupScreen() })
        c.addView(secondaryButton("ACCESO PROFESIONAL") { workHome() })
        c.addView(heading("Registros recientes · máximo 3", 15f))
        val list = root(); c.addView(list)
        show(scroll(c))
        listeners.add(repo.observePets(3) { pets, cache, error ->
            list.removeAllViews()
            if (error != null) list.addView(tv("Error: $error"))
            else if (pets.isEmpty()) list.addView(tv(if (cache) "Sin registros en caché; conecta para verificar." else "Todavía no hay mascotas registradas."))
            else pets.forEach { list.addView(petCard(it, cache)) }
        })
    }
    private fun petCard(p: Pet, cache: Boolean) = card().apply {
        orientation = LinearLayout.HORIZONTAL; isFocusable = true
        contentDescription = "Abrir ficha de ${p.name}, ${p.species}, raza ${p.breed}, ${territoryLabel(p.territoryId)}, ${p.status}. ${state(p.pending, cache)}"
        setOnClickListener { petDetail(p.id) }
        val res = photoResource(p.photoKey)
        if (res != 0) addView(ImageView(this@MainActivity).apply {
            setPhoto(this, res, dp(76)); scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(softTeal, 13, Color.TRANSPARENT, 0); clipToOutline = true
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }, LinearLayout.LayoutParams(dp(76), dp(76)))
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
            addView(tv(p.name, 16f, true))
            addView(tv("${p.species} · ${p.breed}", 12f, false, gray))
            addView(tv(territoryLabel(p.territoryId), 11f, false, gray))
            addView(pill(state(p.pending, cache), !p.pending && !cache))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        addView(tv("›", 26f, false, teal).apply { gravity = Gravity.CENTER; importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO })
    }
    private fun pets() {
        remember("pets", 2)
        val c = root(); c.addView(header("Directorio de mascotas", "Registros públicos · 30 más recientes"))
        c.addView(button("+ REGISTRAR MASCOTA") { newPet() })
        c.addView(secondaryButton("ESCANEAR CÓDIGO QR") { startQrScanner() })
        val search = field("Buscar por nombre, especie, raza, comuna o código", 100); c.addView(search)
        val status = messageView("Cargando mascotas…"); c.addView(status)
        val list = root(); c.addView(list)
        var currentPets = emptyList<Pet>()
        var currentCache = false
        var currentError: String? = null
        fun renderPets() {
            list.removeAllViews()
            val terms = searchable(search.text.toString()).split(" ").filter { it.isNotBlank() }
            val visible = currentPets.filter { pet ->
                val text = searchable(listOf(pet.name, pet.species, pet.breed, pet.color,
                    territoryLabel(pet.territoryId), pet.qrCode).joinToString(" "))
                terms.all(text::contains)
            }
            status.text = when {
                currentError != null -> "No se pudo actualizar: $currentError"
                currentPets.isEmpty() && currentCache -> "Sin registros en caché. Conéctate y reintenta."
                currentPets.isEmpty() -> "Todavía no hay mascotas registradas."
                terms.isNotEmpty() -> "${visible.size} resultado${if (visible.size == 1) "" else "s"} de ${currentPets.size}."
                currentCache -> "${currentPets.size} registros guardados en este dispositivo; pueden requerir actualización."
                else -> "${currentPets.size} mascotas disponibles."
            }
            when {
                currentError != null || currentPets.isEmpty() && currentCache ->
                    list.addView(secondaryButton("REINTENTAR") { pets() })
                visible.isEmpty() && currentPets.isNotEmpty() ->
                    list.addView(infoCard("Sin coincidencias", "Prueba otro nombre, especie, comuna o código.", "⌕"))
                else -> visible.forEach { list.addView(petCard(it, currentCache)) }
            }
        }
        val applySearch = Runnable { if (search.isAttachedToWindow) renderPets() }
        search.doAfterTextChanged {
            search.removeCallbacks(applySearch)
            search.postDelayed(applySearch, 150L)
        }
        show(scroll(c))
        listeners.add(repo.observePets { pets, cache, error ->
            currentPets = pets; currentCache = cache; currentError = error
            renderPets()
        })
    }
    private fun newPet() {
        remember("newPet", 2)
        val c = root(); c.addView(header("Registrar mascota", "Datos públicos mínimos · sin subir fotografías"))
        c.addView(infoCard("Ficha pública", "Incluye únicamente datos descriptivos. No se publican datos de contacto.", "🐾"))
        val form = card(); form.addView(tv("Información de la mascota", 16f, true))
        val name = field("Nombre", 80); form.addView(name)
        val species = select(listOf("Perro", "Gato")); form.addView(spinnerLabel("Especie", species)); form.addView(species)
        val breed = field("Raza", 80); form.addView(breed)
        val sex = select(listOf("Hembra", "Macho", "No determinado")); form.addView(spinnerLabel("Sexo", sex)); form.addView(sex)
        val age = field("Edad aproximada", 40); form.addView(age)
        val color = field("Color", 80); form.addView(color)
        val territory = select(TERRITORIES.map { it.label }); form.addView(spinnerLabel("Comuna", territory)); form.addView(territory)
        val message = messageView("Las fotos incluidas son solo demostrativas."); form.addView(message)
        val draft = model.petDraft
        bind(name, draft, "name"); bind(breed, draft, "breed"); bind(age, draft, "age"); bind(color, draft, "color")
        bind(species, draft, "species", listOf("Perro", "Gato"))
        bind(sex, draft, "sex", listOf("Hembra", "Macho", "No determinado"))
        bind(territory, draft, "territory", TERRITORIES.map { it.id })
        val submit = button("GUARDAR MASCOTA") {
            if (name.text.isBlank() || breed.text.isBlank() || age.text.isBlank() || color.text.isBlank()) {
                message.text = "Completa nombre, raza, edad y color."
            } else model.submit("pet")
        }
        val another = button("REGISTRAR OTRA MASCOTA") { model.startAnother("pet"); newPet() }
        form.addView(submit); form.addView(another); c.addView(form)
        show(scroll(c))
        attachSubmission("pet", message, submit, another, listOf(name, breed, age, color, species, sex, territory))
    }

    private fun petDetail(id: String) {
        remember("pet:$id", 2)
        val c = root(); c.addView(header("Detalle Mascota", "Ficha pública"))
        val body = root(); c.addView(body); show(scroll(c))
        listeners.add(repo.observePet(id) { p, cache, error ->
            body.removeAllViews()
            if (error != null || p == null) {
                body.addView(tv(error ?: if (cache) "Sin datos en caché; conecta para consultar." else "No existe la mascota"))
                return@observePet
            }
            val res = photoResource(p.photoKey)
            if (res != 0) body.addView(ImageView(this).apply {
                setPhoto(this, res); scaleType = ImageView.ScaleType.CENTER_CROP
                background = rounded(softTeal, 18, Color.TRANSPARENT, 0); clipToOutline = true
                contentDescription = "Fotografía ilustrativa de ${p.name}"
            }, LinearLayout.LayoutParams(-1, dp(210)).apply { setMargins(dp(12), dp(12), dp(12), dp(4)) })
            body.addView(card().apply {
                addView(tv(p.name, 24f, true)); addView(tv("${p.species} · ${p.breed}", 14f, false, gray))
                addView(pill(p.status)); addView(tv("Sexo: ${p.sex}\nEdad: ${p.age}\nColor: ${p.color}\nTerritorio: ${territoryLabel(p.territoryId)}\nCódigo: ${p.qrCode}").apply { setLineSpacing(0f, 1.2f) })
                addView(pill(state(p.pending, cache), !p.pending && !cache))
            })
            body.addView(infoCard("Datos del responsable protegidos", "Esta ficha no contiene teléfono, dirección ni correo.", "🔒"))
            body.addView(secondaryButton("← VOLVER") { pets() })
        })
    }
    private fun startQrScanner() {
        val options = GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
            .enableAutoZoom()
            .build()
        GmsBarcodeScanning.getClient(this, options).startScan()
            .addOnSuccessListener { barcode ->
                val value = barcode.rawValue.orEmpty()
                if (publicQrCode(value) == null) {
                    qrLookupScreen(scannerMessage = "El QR leído no contiene un código público válido de Mascotas Municipales.")
                } else qrLookupScreen(value)
            }
            .addOnCanceledListener { }
            .addOnFailureListener {
                qrLookupScreen(scannerMessage = "No se pudo abrir el lector en este dispositivo. Puedes escribir el código manualmente.")
            }
    }

    private fun qrLookupScreen(initialCode: String = "", scannerMessage: String = "") {
        if (model.ready) remember("qr", 2) else publicQrOpen = true
        val c = root(); c.addView(header("Consulta por QR", "Ficha pública de la mascota"))
        c.addView(infoCard("Consulta segura", "El resultado no muestra correo, teléfono, dirección ni datos del responsable.", "▣"))
        val form = card(); form.addView(tv("Código público", 16f, true))
        val code = field("Ejemplo: ZPQ-LUNA0000", 120); form.addView(code)
        if (initialCode.isNotBlank()) code.setText(publicQrCode(initialCode).orEmpty())
        val message = messageView(scannerMessage.ifBlank { "Escanea un QR o escribe el código impreso en la ficha." }); form.addView(message)
        val results = root()
        fun lookup() {
            val normalized = publicQrCode(code.text.toString())
            if (normalized == null) {
                message.text = "Escribe un código válido con el formato ZPQ- seguido de letras o números."
                return
            }
            code.setText(normalized); code.setSelection(normalized.length)
            message.text = "Consultando $normalized…"
            results.removeAllViews()
            val generation = screenGeneration
            repo.findPetByQrCode(normalized) { pet, cache, error ->
                if (generation != screenGeneration) return@findPetByQrCode
                results.removeAllViews()
                message.text = when {
                    error != null -> "No se pudo consultar: $error"
                    pet == null && cache -> "El código no está en la caché. Conéctate y vuelve a intentar."
                    pet == null -> "No existe una mascota pública con ese código."
                    cache -> "Ficha recuperada de la caché; puede requerir actualización."
                    else -> "Ficha pública encontrada."
                }
                if (pet != null) results.addView(card().apply {
                    addView(tv(pet.name, 22f, true))
                    addView(pill(pet.status))
                    addView(tv("${pet.species} · ${pet.breed}\nSexo: ${pet.sex}\nEdad: ${pet.age}\nColor: ${pet.color}\n${territoryLabel(pet.territoryId)}\nCódigo: ${pet.qrCode}").apply {
                        setLineSpacing(0f, 1.2f)
                    })
                    if (model.ready) addView(button("ABRIR FICHA COMPLETA") { petDetail(pet.id) })
                })
                if (error != null || pet == null) results.addView(secondaryButton("REINTENTAR") { lookup() })
            }
        }
        form.addView(button("CONSULTAR CÓDIGO") { lookup() })
        form.addView(secondaryButton("ESCANEAR CON LA CÁMARA") { startQrScanner() })
        c.addView(form); c.addView(results)
        c.addView(secondaryButton("← VOLVER") {
            if (model.ready) pets() else { publicQrOpen = false; authScreen() }
        })
        show(scroll(c))
        if (initialCode.isNotBlank() && publicQrCode(initialCode) != null) lookup()
    }

    private fun reportCard(r: Report, cache: Boolean) = card().apply {
        isFocusable = true
        contentDescription = "Abrir reporte de ${r.petName.ifBlank { "mascota sin identificar" }}, ${r.type}, ${r.status}, ${date(r.createdAt)}. ${state(r.pending, cache)}"
        setOnClickListener { reportDetail(r.id) }
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        addView(LinearLayout(this@MainActivity).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(tv(r.petName.ifBlank { "Mascota sin identificar" }, 16f, true).apply {
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(pill(r.type))
        })
        addView(tv("${r.status} · ${date(r.createdAt)}", 12f, false, gray).apply {
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        })
        addView(pill(state(r.pending, cache), !r.pending && !cache).apply {
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        })
    }
    private fun reports() {
        remember("reports", 1)
        val c = root(); c.addView(header("Mis reportes", "30 más recientes"))
        c.addView(button("+ NUEVO REPORTE") { newReport() })
        val filters = listOf("Todos", "Abiertos", "Resueltos", "Cerrados")
        val filter = select(filters); c.addView(spinnerLabel("Filtrar por estado", filter)); c.addView(filter)
        val status = messageView("Cargando reportes…"); c.addView(status)
        val list = root(); c.addView(list); show(scroll(c))
        val generation = screenGeneration
        val requestedUid = repo.uid
        var currentReports = emptyList<Report>()
        var currentCache = false
        var currentError: String? = null
        fun renderReports() {
            list.removeAllViews()
            val visible = currentReports.filter { report -> when (filter.selectedItemPosition) {
                1 -> report.status == "Abierto"
                2 -> report.status == "Resuelto"
                3 -> report.status == "Cerrado"
                else -> true
            } }
            status.text = when {
                currentError != null -> "No se pudo actualizar: $currentError"
                currentReports.isEmpty() && currentCache -> "Sin reportes en caché. Conéctate y reintenta."
                currentReports.isEmpty() -> "Todavía no hay reportes visibles."
                else -> "${visible.size} de ${currentReports.size} reportes · ${filters[filter.selectedItemPosition]}."
            }
            if (currentError != null || currentReports.isEmpty() && currentCache) {
                list.addView(secondaryButton("REINTENTAR") { reports() })
                return
            }
            if (visible.isEmpty() && currentReports.isNotEmpty()) {
                list.addView(infoCard("Sin reportes en este filtro", "Selecciona otro estado para ver más resultados.", "⌕"))
                return
            }
            visible.forEach { r -> list.addView(reportCard(r, currentCache)) }
        }
        filter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = renderReports()
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        run {
            if (generation == screenGeneration && requestedUid == repo.uid) {
                val display: (List<Report>, Boolean, String?) -> Unit = { reports, cache, error ->
                    currentReports = reports; currentCache = cache; currentError = error
                    renderReports()
                }
                listeners.add(repo.observeMyReports(display))
            }
        }
    }
    private fun newReport() {
        remember("newReport", 1)
        val c = root(); c.addView(header("Nuevo Reporte", "Los datos se guardan en Firestore"))
        c.addView(infoCard("Reporte ciudadano", "Describe el caso con claridad. La función de fotografía sigue siendo simulada y no sube archivos.", "!"))
        val form = card(); form.addView(tv("Información del reporte", 16f, true))
        val name = field("Nombre de mascota (si se conoce)", 80); form.addView(name)
        val type = select(listOf("Pérdida", "Encontrado", "Avistamiento")); form.addView(spinnerLabel("Tipo de reporte", type)); form.addView(type)
        val species = select(listOf("Perro", "Gato")); form.addView(spinnerLabel("Especie", species)); form.addView(species)
        val territory = select(TERRITORIES.map { it.label }); form.addView(spinnerLabel("Ubicación (comuna)", territory)); form.addView(territory)
        val desc = field("Describe lo que observaste", 2000).apply {
            minLines = 4; minimumHeight = dp(110); gravity = Gravity.TOP
        }; form.addView(desc)
        form.addView(tv("No incluyas datos personales de terceros.", 11f, false, gray).apply { setPadding(dp(14), dp(2), dp(14), dp(6)) })
        val message = messageView(""); form.addView(message)
        val draft = model.reportDraft
        bind(name, draft, "name"); bind(desc, draft, "description")
        bind(type, draft, "type", listOf("Pérdida", "Encontrado", "Avistamiento"))
        bind(species, draft, "species", listOf("Perro", "Gato"))
        bind(territory, draft, "territory", TERRITORIES.map { it.id })
        val submit = button("ENVIAR REPORTE") {
            if (desc.text.isBlank()) message.text = "Escribe una descripción."
            else model.submit("report")
        }
        val another = button("CREAR OTRO REPORTE") { model.startAnother("report"); newReport() }
        form.addView(submit); form.addView(another); c.addView(form)
        show(scroll(c))
        attachSubmission("report", message, submit, another, listOf(name, desc, type, species, territory))
    }

    private fun reportDetail(id: String) {
        remember("report:$id", 1)
        val c = root(); c.addView(header("Detalle del reporte", "Seguimiento"))
        val body = root(); c.addView(body); show(scroll(c))
        listeners.add(repo.observeReport(id) { r, cache, error ->
            body.removeAllViews()
            if (error != null || r == null) {
                body.addView(tv(error ?: if (cache) "Sin datos en caché; conecta para consultar." else "No existe el reporte"))
                return@observeReport
            }
            body.addView(card().apply {
                addView(tv("${r.petName.ifBlank { "Mascota sin identificar" }} · ${r.type}", 20f, true))
                addView(pill(r.status)); addView(tv("Especie: ${r.species}\nComuna: ${territoryLabel(r.territoryId)}\nDescripción: ${r.description}\nFecha: ${date(r.createdAt)}").apply { setLineSpacing(0f, 1.2f) })
                addView(pill(state(r.pending, cache), !r.pending && !cache))
            })
            if (r.status == "Abierto") body.addView(button("MARCAR RESUELTO") {
                syncMessage = "Pendiente de sincronización"
                repo.updateReportStatus(r.id, "Resuelto") { failure ->
                    syncMessage = if (failure == null) "Sincronizado" else "Falló: $failure"
                    toast(syncMessage)
                }
            })
            body.addView(secondaryButton("← VOLVER") { reports() })
            body.addView(button("VER SEGUIMIENTO DEL CASO") { citizenCase(id) })
        })
    }
    private fun territory() {
        remember("territory", 3)
        val c = root(); c.addView(header("Territorio", "Comunas del prototipo"))
        c.addView(infoCard("Zipaquirá", "División usada para clasificar registros. No se muestran cifras municipales sin verificar.", "⌖"))
        c.addView(heading("Mapa de Zipaquirá"))
        c.addView(tv("Mapa interactivo de referencia. Requiere internet la primera vez; las vistas recientes se conservan temporalmente en caché.", 12f, false, gray).apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), 0, dp(14), dp(7)) }
        })
        val mapHolder = FrameLayout(this).apply {
            background = rounded(if (highContrast) Color.WHITE else Color.rgb(224, 232, 235), 14, border, 1)
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(-1, dp(310)).apply { setMargins(dp(12), dp(5), dp(12), dp(5)) }
        }
        c.addView(mapHolder)
        c.addView(secondaryButton("CENTRAR MAPA EN ZIPAQUIRÁ") {
            activeMap?.controller?.apply {
                setZoom(14.0)
                animateTo(ZIPAQUIRA_CENTER)
            }
        })
        c.addView(heading("Comunas disponibles"))
        TERRITORIES.forEachIndexed { index, territory -> c.addView(card().apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(tv("${index + 1}", 15f, true, Color.WHITE).apply {
                gravity = Gravity.CENTER; background = rounded(teal, 30, Color.TRANSPARENT, 0)
            }, LinearLayout.LayoutParams(dp(42), dp(42)))
            addView(tv(territory.label.substringAfter("· ", territory.label), 15f, true).apply { setPadding(dp(14), 0, 0, 0) })
        }) }
        c.addView(heading("Próximos eventos aprobados"))
        val eventMessage = messageView("Consultando jornadas y eventos…"); c.addView(eventMessage)
        val eventList = root(); c.addView(eventList)
        show(scroll(c))
        attachTerritoryMap(mapHolder)
        val generation = screenGeneration
        repo.approvedEvents { events, cache, error ->
            if (generation != screenGeneration) return@approvedEvents
            eventList.removeAllViews()
            eventMessage.text = when {
                error != null -> "No se pudieron consultar los eventos: $error"
                events.isEmpty() && cache -> "No hay eventos en la caché. Conéctate para comprobar nuevas jornadas."
                events.isEmpty() -> "Todavía no hay eventos aprobados próximos."
                cache -> "Eventos guardados en este dispositivo; pueden requerir actualización."
                else -> "${events.size} evento${if (events.size == 1) "" else "s"} próximo${if (events.size == 1) "" else "s"}."
            }
            if (error != null || events.isEmpty() && cache) {
                eventList.addView(secondaryButton("REINTENTAR EVENTOS") { territory() })
            }
            events.forEach { event -> eventList.addView(card().apply {
                addView(LinearLayout(this@MainActivity).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    addView(tv(event.title, 17f, true), LinearLayout.LayoutParams(0, -2, 1f))
                    addView(pill(event.type))
                })
                addView(tv(dateTime(event.scheduledAt), 14f, true, tealDark))
                addView(tv("${territoryLabel(event.territoryId)}\nLugar: ${event.location}", 12f, false, gray))
                addView(tv(event.description, 13f).apply { setPadding(dp(2), dp(8), dp(2), dp(2)) })
            }) }
        }
    }
    private fun workHome() {
        remember("work", 4)
        val c = root(); c.addView(header("Acceso profesional", "Dependencia municipal · Zipaquirá"))
        val message = messageView("Verificando permisos con el servidor…"); c.addView(message)
        c.addView(secondaryButton("VOLVER A INICIO") { model.requestedWorkspace = "citizen"; home() })
        show(scroll(c))
        val generation = screenGeneration; val account = repo.uid
        work.access { access, error ->
            if (generation != screenGeneration || account != repo.uid) return@access
            if (access == null) { message.text = error; return@access }
            if (model.requestedWorkspace != "citizen" && model.requestedWorkspace != access.role) {
                message.text = "La cuenta no tiene el rol elegido. Tu acceso aprobado es ${if (access.role == "vet") "Veterinario" else "Administrador"}."
                c.addView(button("ABRIR MI ACCESO APROBADO") { model.requestedWorkspace = access.role; workHome() })
                return@access
            }
            message.text = if (access.role == "admin") "Administrador de la dependencia" else "Veterinario"
            c.addView(infoCard("Operación conectada", "Los cambios se confirman únicamente cuando responde el servidor. Usa solo datos ficticios.", "↻"))
            if (access.role == "admin") {
                c.addView(button("REVISAR REPORTES") { workList("reports", access) })
                c.addView(button("EQUIPO VETERINARIO") { workList("access", access) })
                c.addView(button("SOLICITUDES DE EVENTOS") { workList("eventRequests", access) })
            } else {
                c.addView(button("PROPONER EVENTO TERRITORIAL") { eventProposal() })
                c.addView(secondaryButton("MIS SOLICITUDES DE EVENTOS") { workList("myEvents", access) })
            }
            c.addView(button(if (access.role == "admin") "CASOS DE LA DEPENDENCIA" else "MIS CASOS Y SEGUIMIENTOS") { workList("cases", access) })
        }
    }

    private fun eventProposal() {
        remember("workevent", 4)
        val c = root(); c.addView(header("Proponer evento", "Requiere aprobación administrativa"))
        c.addView(infoCard("Solicitud veterinaria", "El evento solo aparecerá en Territorio después de que un administrador lo apruebe.", "✦"))
        val form = card(); form.addView(tv("Datos del evento", 16f, true))
        val values = model.workDrafts.getOrPut("eventProposal") { mutableMapOf() }
        val title = field("Nombre del evento", 100).apply {
            setText(values["title"].orEmpty()); doAfterTextChanged { values["title"] = it.toString() }
        }; form.addView(title)
        val types = listOf("Vacunación", "Esterilización", "Bienestar animal", "Otro")
        val type = select(types); form.addView(spinnerLabel("Tipo de jornada", type)); form.addView(type)
        type.setSelection(types.indexOf(values["type"] ?: types.first()).coerceAtLeast(0))
        type.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { values["type"] = types[position] }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        val territoryIds = TERRITORIES.map { it.id }
        val territory = select(TERRITORIES.map { it.label }); form.addView(spinnerLabel("Comuna", territory)); form.addView(territory)
        territory.setSelection(territoryIds.indexOf(values["territory"] ?: territoryIds.first()).coerceAtLeast(0))
        territory.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { values["territory"] = territoryIds[position] }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        val location = field("Lugar específico o punto de encuentro", 160).apply {
            setText(values["location"].orEmpty()); doAfterTextChanged { values["location"] = it.toString() }
        }; form.addView(location)
        val description = field("Descripción, requisitos y recomendaciones", 1000).apply {
            minLines = 4; gravity = Gravity.TOP
            setText(values["description"].orEmpty()); doAfterTextChanged { values["description"] = it.toString() }
        }; form.addView(description)
        val defaultDate = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        var scheduledMillis = values["scheduledAt"]?.toLongOrNull() ?: defaultDate.timeInMillis
        fun scheduleLabel() = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT,
            Locale.forLanguageTag("es-CO")).format(java.util.Date(scheduledMillis))
        val schedule = secondaryButton("FECHA Y HORA · ${scheduleLabel()}") { }
        schedule.setOnClickListener {
            val selected = Calendar.getInstance().apply { timeInMillis = scheduledMillis }
            DatePickerDialog(this, { _, year, month, day ->
                selected.set(year, month, day)
                TimePickerDialog(this, { _, hour, minute ->
                    selected.set(Calendar.HOUR_OF_DAY, hour); selected.set(Calendar.MINUTE, minute)
                    selected.set(Calendar.SECOND, 0); selected.set(Calendar.MILLISECOND, 0)
                    scheduledMillis = selected.timeInMillis; values["scheduledAt"] = scheduledMillis.toString()
                    schedule.text = "FECHA Y HORA · ${scheduleLabel()}"
                }, selected.get(Calendar.HOUR_OF_DAY), selected.get(Calendar.MINUTE), true).show()
            }, selected.get(Calendar.YEAR), selected.get(Calendar.MONTH), selected.get(Calendar.DAY_OF_MONTH)).show()
        }
        form.addView(schedule)
        val result = messageView("Verificando tu acceso veterinario…"); form.addView(result)
        lateinit var submit: Button
        submit = button("ENVIAR PARA APROBACIÓN") {
            when {
                title.text.isBlank() || location.text.isBlank() || description.text.isBlank() ->
                    result.text = "Completa nombre, lugar y descripción."
                scheduledMillis <= System.currentTimeMillis() -> result.text = "Elige una fecha y hora futuras."
                else -> {
                    submit.isEnabled = false; result.text = "Esperando confirmación del servidor…"
                    work.proposeEvent(title.text.toString(), values["type"] ?: types.first(),
                        values["territory"] ?: territoryIds.first(), location.text.toString(),
                        description.text.toString(), com.google.firebase.Timestamp(java.util.Date(scheduledMillis))) { failure ->
                        if (failure == null) {
                            model.workDrafts.remove("eventProposal")
                            toast("Solicitud enviada al administrador"); workHome()
                        } else {
                            submit.isEnabled = true; result.text = "No confirmado: $failure"
                        }
                    }
                }
            }
        }.apply { isEnabled = false }
        form.addView(submit); c.addView(form)
        c.addView(secondaryButton("VOLVER AL PANEL") { workHome() })
        show(scroll(c))
        val generation = screenGeneration; val account = repo.uid
        work.access { access, error ->
            if (generation == screenGeneration && account == repo.uid) {
                submit.isEnabled = access?.role == "vet"
                result.text = if (access?.role == "vet") "Borrador temporal listo para enviar."
                else error ?: "Esta acción requiere un acceso veterinario activo."
            }
        }
    }

    private fun workList(kind: String, access: WorkAccess, cursor: com.google.firebase.firestore.DocumentSnapshot? = null) {
        remember("work", 4)
        val title = when (kind) {
            "reports" -> "Reportes para revisión"
            "access" -> "Equipo veterinario"
            "eventRequests" -> "Solicitudes de eventos"
            "myEvents" -> "Mis solicitudes"
            else -> "Casos y seguimientos"
        }
        val c = root(); c.addView(header(title, "20 por página · lectura del servidor"))
        c.addView(secondaryButton("VOLVER AL PANEL") { workHome() })
        val message = messageView("Cargando…"); c.addView(message); show(scroll(c))
        val generation = screenGeneration; val account = repo.uid
        work.page(kind, access, cursor) { docs, error ->
            if (generation != screenGeneration || account != repo.uid) return@page
            message.text = error ?: if (docs.isNullOrEmpty()) "No hay más registros." else "${docs.size} registros en esta página."
            docs.orEmpty().forEach { doc ->
                c.addView(card().apply {
                    if (kind == "access") {
                        addView(tv(doc.getString("displayName") ?: "Veterinario de demostración", 16f, true))
                        addView(pill(if (doc.getBoolean("active") == true) "Activo" else "Suspendido", doc.getBoolean("active") == true))
                        addView(tv("UID: ${doc.id}", 12f, false, gray).apply { setTextIsSelectable(true) })
                        addView(tv("Aprobaciones y revocaciones: responsable de Firebase, mediante procedimiento documentado.", 12f))
                    } else if (kind in listOf("eventRequests", "myEvents")) {
                        addView(LinearLayout(this@MainActivity).apply {
                            gravity = Gravity.CENTER_VERTICAL
                            addView(tv(doc.getString("title").orEmpty(), 16f, true), LinearLayout.LayoutParams(0, -2, 1f))
                            addView(pill(doc.getString("status").orEmpty(), doc.getString("status") == "Aprobado"))
                        })
                        addView(tv("${doc.getString("type")} · ${dateTime(doc.getTimestamp("scheduledAt"))}", 13f, true, tealDark))
                        addView(tv("${territoryLabel(doc.getString("territoryId").orEmpty())}\nLugar: ${doc.getString("location")}\n${doc.getString("description")}", 12f, false, gray))
                        if (kind == "eventRequests") {
                            val result = messageView(""); addView(result)
                            val approve = button("APROBAR Y PUBLICAR") { }
                            val reject = secondaryButton("RECHAZAR SOLICITUD") { }
                            fun review(accepted: Boolean) {
                                approve.isEnabled = false; reject.isEnabled = false
                                result.text = "Esperando confirmación del servidor…"
                                work.reviewEvent(doc.id, accepted) { failure ->
                                    if (generation == screenGeneration && account == repo.uid) {
                                        if (failure == null) {
                                            toast(if (accepted) "Evento aprobado y publicado" else "Solicitud rechazada")
                                            workList("eventRequests", access)
                                        } else {
                                            approve.isEnabled = true; reject.isEnabled = true
                                            result.text = "No confirmado: $failure"
                                        }
                                    }
                                }
                            }
                            approve.setOnClickListener { review(true) }
                            reject.setOnClickListener { review(false) }
                            addView(approve); addView(reject)
                        }
                    } else {
                        addView(tv(doc.getString("petName").orEmpty().ifBlank { "Mascota sin identificar" }, 16f, true))
                        addView(tv("${doc.getString("status")} · ${date(doc.getTimestamp("updatedAt"))}"))
                        if (kind == "reports") {
                            addView(tv("${doc.getString("type")} · ${doc.getString("species")}\n${territoryLabel(doc.getString("territoryId").orEmpty())}\n${doc.getString("description")}"))
                            val result = tv(""); addView(result)
                            lateinit var review: Button
                            review = button("REVISAR / ABRIR CASO") {
                                review.isEnabled = false; result.text = "Esperando confirmación…"
                                work.review(doc.id) { failure ->
                                    if (generation == screenGeneration && account == repo.uid) {
                                        review.isEnabled = true
                                        if (failure == null) workCase(doc.id) else result.text = "No confirmado: $failure"
                                    }
                                }
                            }
                            addView(review)
                        } else addView(button("ABRIR CASO") { workCase(doc.id) })
                    }
                })
            }
            if (docs?.size == 20) c.addView(button("SIGUIENTE PÁGINA") { workList(kind, access, docs.last()) })
            c.addView(button("ACTUALIZAR DESDE EL INICIO") { workList(kind, access) })
        }
    }

    private fun workCase(id: String) {
        remember("workcase:$id", 4)
        val c = root(); c.addView(header("Caso municipal", "Información operativa · datos ficticios"))
        val message = messageView("Comprobando acceso y versión…"); c.addView(message)
        c.addView(secondaryButton("VOLVER AL PANEL") { workHome() }); show(scroll(c))
        val generation = screenGeneration; val account = repo.uid
        fun current() = generation == screenGeneration && account == repo.uid
        work.access { access, error ->
            if (!current()) return@access
            if (access == null) { message.text = error; return@access }
            work.getCase(id) caseResult@ { doc, failure ->
                if (!current()) return@caseResult
                if (doc == null) { message.text = failure ?: "No existe el caso."; return@caseResult }
                val status = doc.getString("status").orEmpty()
                val version = doc.getLong("version") ?: 0
                message.text = "${doc.getString("petName").orEmpty().ifBlank { "Mascota sin identificar" }} · ${doc.getString("species")}\nEstado: $status\n${territoryLabel(doc.getString("territoryId").orEmpty())}\nVeterinario: ${doc.getString("vetId").orEmpty().ifBlank { "Sin asignar" }}\nResultado para el ciudadano: ${doc.getString("outcome").orEmpty().ifBlank { "En proceso" }}"
                val petId = doc.getString("petId").orEmpty()
                if (petId.isNotBlank()) c.addView(button("VER FICHA PÚBLICA DE LA MASCOTA") { petDetail(petId) })
                c.addView(button("ACTUALIZAR CASO") { workCase(id) })
                val result = tv(""); c.addView(result)
                var busy = false
                fun submit(next: String, vetId: String = "", outcome: String = "", examination: String = "", care: String = "", followUp: String = "") {
                    if (busy) return
                    busy = true; result.text = "Esperando confirmación del servidor…"
                    work.change(id, version, next, vetId, outcome, examination, care, followUp) { e ->
                        if (current()) {
                            busy = false
                            if (e == null) { model.workDrafts.remove(id); toast("Cambio confirmado por el servidor"); workCase(id) }
                            else result.text = "No confirmado: $e. Actualiza para comprobar el estado antes de reintentar."
                        }
                    }
                }
                if (access.role == "admin") {
                    if (status in listOf("Revisado", "Asignado")) {
                        val vet = field("UID del veterinario aprobado", 128); c.addView(vet)
                        c.addView(tv("Copia el UID del menú Equipo veterinario. Se valida su rol, dependencia y estado activo.", 12f))
                        c.addView(button("ASIGNAR VETERINARIO") {
                            if (vet.text.isBlank()) result.text = "Escribe el UID del veterinario." else submit("Asignado", vetId = vet.text.toString())
                        })
                    }
                    if (status in listOf("Revisado", "Atendido")) {
                        val outcome = field("Resultado para el ciudadano, sin datos clínicos ni contactos", 1000); c.addView(outcome)
                        c.addView(button("CERRAR CASO Y REPORTE") {
                            if (outcome.text.isBlank()) result.text = "Escribe el resultado." else submit("Cerrado", outcome = outcome.text.toString())
                        })
                    }
                    c.addView(tv("La historia clínica está reservada al veterinario asignado.", 12f))
                } else if (doc.getString("vetId") == account) {
                    if (status in listOf("Asignado", "Atendido")) {
                        val values = model.workDrafts.getOrPut(id) { mutableMapOf() }
                        fun clinicalField(key: String, label: String, max: Int): EditText {
                            c.addView(tv(label, 14f, true))
                            return field(label, max).apply {
                                setText(values[key].orEmpty()); doAfterTextChanged { values[key] = it.toString() }
                                c.addView(this)
                            }
                        }
                        c.addView(tv("Borrador temporal: se conserva al girar la pantalla, pero no al cerrar el proceso. Cada envío es definitivo; corrige mediante una nueva entrada.", 12f))
                        val exam = clinicalField("examination", "Valoración / motivo", 2000)
                        val care = clinicalField("care", "Atención realizada", 2000)
                        val follow = clinicalField("followUp", "Seguimiento recomendado", 1000)
                        c.addView(button("GUARDAR ATENCIÓN DEFINITIVA") {
                            if (exam.text.isBlank() || care.text.isBlank()) result.text = "Completa valoración y atención."
                            else submit("Atendido", examination = exam.text.toString(), care = care.text.toString(), followUp = follow.text.toString())
                        })
                    }
                    c.addView(heading("Atenciones registradas · privadas"))
                    fun records(cursor: com.google.firebase.firestore.DocumentSnapshot? = null) {
                        work.records(id, cursor) { notes, noteError ->
                            if (current()) {
                                if (noteError != null) c.addView(tv("No se pudieron leer las atenciones: $noteError"))
                                notes.orEmpty().forEach { n -> c.addView(card().apply {
                                    addView(tv("${date(n.getTimestamp("createdAt"))}\nValoración: ${n.getString("examination")}\nAtención: ${n.getString("care")}\nSeguimiento: ${n.getString("followUp")}"))
                                }) }
                                if (notes?.size == 20) {
                                    lateinit var more: Button
                                    more = button("MÁS ATENCIONES") { more.isEnabled = false; records(notes.last()) }; c.addView(more)
                                }
                            }
                        }
                    }
                    records()
                }
            }
        }
    }

    private fun citizenCase(id: String) {
        remember("report:$id", 1)
        val c = root(); c.addView(header("Seguimiento municipal"))
        val message = messageView("Consultando servidor…"); c.addView(message)
        c.addView(secondaryButton("VOLVER AL REPORTE") { reportDetail(id) }); show(scroll(c))
        val generation = screenGeneration; val account = repo.uid
        work.getCase(id) { doc, error ->
            if (generation == screenGeneration && account == repo.uid) message.text = error ?: if (doc == null)
                "Tu reporte todavía no tiene un caso municipal."
            else "Estado: ${doc.getString("status")}\nResultado: ${doc.getString("outcome").orEmpty().ifBlank { "En proceso" }}\nActualizado: ${date(doc.getTimestamp("updatedAt"))}"
        }
    }

    private fun upcomingOption(title: String, detail: String = "") = card().apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; alpha = .78f
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv(title, 15f, true))
            if (detail.isNotBlank()) addView(tv(detail, 12f, false, gray))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        addView(pill("Próximamente", false))
    }
    private fun accessibilityToggle(title: String, detail: String, key: String, checked: Boolean, update: (Boolean) -> Unit) = card().apply {
        addView(SwitchCompat(this@MainActivity).apply {
            text = title; isChecked = checked; textSize = 16f * textScale; setTextColor(dark)
            minHeight = dp(56)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(teal, if (highContrast) Color.DKGRAY else Color.GRAY)
            )
            setOnCheckedChangeListener { _, value ->
                accessibilityScrollY = (content.getChildAt(0) as? ScrollView)?.scrollY ?: 0
                update(value)
                accessibilityPreferences.edit().putBoolean(key, value).apply()
                showApp()
            }
        })
        addView(tv(detail, 13f, false, gray))
    }
    private fun accessibilityScreen() {
        accessibilityOpen = true
        if (model.ready) remember("accessibility", 4)
        applySystemBars()
        val c = root(); c.addView(header("Accesibilidad", "Ajustes guardados en este dispositivo"))
        c.addView(infoCard("Una app que se adapta a ti", "Estos cambios solo se guardan en este dispositivo y no se envían a Firebase.", "A"))
        c.addView(heading("Lectura y colores"))
        c.addView(accessibilityToggle("Texto más grande",
            "Aumenta el texto de la app y deja espacio para el tamaño de fuente configurado en Android.",
            "large_text", largeText) { largeText = it })
        c.addView(accessibilityToggle("Contraste alto",
            "Usa texto negro, fondo blanco y bordes definidos para distinguir los controles.",
            "high_contrast", highContrast) { highContrast = it })
        c.addView(accessibilityToggle("Paleta para daltonismo",
            "Usa azul como color principal. Los estados también se muestran con palabras. Con contraste alto activo se prioriza el blanco y negro.",
            "colorblind_palette", colorblindPalette) { colorblindPalette = it })
        c.addView(heading("Lector de pantalla", 16f))
        c.addView(card().apply {
            addView(tv("La app tiene etiquetas para TalkBack en navegación, formularios, fotos y registros. TalkBack se activa desde los ajustes de Android.", 13f))
        })
        c.addView(button("ABRIR ACCESIBILIDAD DE ANDROID") {
            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            catch (_: ActivityNotFoundException) { toast("Este dispositivo no tiene ajustes de accesibilidad disponibles.") }
        })
        c.addView(secondaryButton("← VOLVER") {
            accessibilityOpen = false; accessibilityScrollY = 0
            if (!model.ready) authScreen() else profileMenu()
        })
        val settingsScroll = scroll(c)
        show(settingsScroll)
        if (accessibilityScrollY > 0) settingsScroll.post { settingsScroll.scrollTo(0, accessibilityScrollY) }
    }
    @Suppress("DEPRECATION")
    private fun appVersion(): String = packageManager.getPackageInfo(packageName, 0).versionName ?: "desconocida"

    private fun aboutScreen() {
        remember("about", 4)
        val c = root(); c.addView(header("Información de la aplicación", "Versión y alcance del prototipo"))
        c.addView(infoCard("Mascotas Municipales", "Versión ${appVersion()} · aplicación Android nativa en Kotlin para Zipaquirá.", "🐾"))
        c.addView(card().apply {
            addView(heading("Propósito"))
            addView(tv("Prototipo académico orientado a la Secretaría de Desarrollo Rural y Ambiente para registrar mascotas, reportar pérdidas o hallazgos, consultar fichas públicas y publicar jornadas aprobadas.", 13f))
        })
        c.addView(card().apply {
            addView(heading("Privacidad"))
            addView(tv("Las fichas públicas no muestran correo, teléfono, dirección ni contraseña. Los datos de acceso se gestionan mediante Firebase Authentication.", 13f))
        })
        c.addView(card().apply {
            addView(heading("Tecnologías"))
            addView(tv("Kotlin · Android API 33 · Firebase Authentication · Cloud Firestore · OpenStreetMap · lector QR de Google Play Services.", 13f))
            addView(tv("Plan Firebase Spark sin facturación vinculada. OpenStreetMap se utiliza con atribución y caché limitada.", 12f, false, gray))
        })
        c.addView(infoCard("Alcance académico", "No representa una operación municipal en producción y utiliza únicamente información ficticia para las demostraciones.", "i"))
        c.addView(secondaryButton("← VOLVER AL PERFIL") { profileMenu() })
        show(scroll(c))
    }
    private fun profileMenu() {
        remember("profile", 4)
        val c = root(); c.addView(header("Mi perfil", "Cuenta y preferencias"))
        c.addView(card().apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(tv(repo.email.take(1).uppercase(), 20f, true, Color.WHITE).apply {
                gravity = Gravity.CENTER; background = rounded(teal, 40, Color.TRANSPARENT, 0)
            }, LinearLayout.LayoutParams(dp(52), dp(52)))
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0)
                addView(tv(repo.email, 16f, true)); addView(tv("Cuenta ciudadana", 12f, false, gray))
            }, LinearLayout.LayoutParams(0, -2, 1f))
        })
        c.addView(card().apply {
            isFocusable = true
            contentDescription = "Abrir ajustes de accesibilidad: texto más grande, contraste alto, paleta para daltonismo y TalkBack"
            setOnClickListener { accessibilityOpen = true; accessibilityScreen() }
            addView(heading("Accesibilidad").apply { importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO })
            addView(tv("Texto grande, contraste alto, colores accesibles y lector de pantalla.", 12f, false, gray).apply {
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            })
        })
        c.addView(button("INFORMACIÓN DE LA APLICACIÓN") { aboutScreen() })
        c.addView(secondaryButton("ACCESO PROFESIONAL") { workHome() })
        c.addView(upcomingOption("Información de tu cuenta"))
        c.addView(upcomingOption("Cambiar correo electrónico"))
        c.addView(upcomingOption("Cambiar contraseña"))
        c.addView(upcomingOption("Cambiar información de tus mascotas"))
        c.addView(secondaryButton("CERRAR SESIÓN") {
            accessibilityOpen = false; model.logout()
        })
        show(scroll(c))
    }
}
